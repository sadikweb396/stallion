<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StallionController extends Controller
{
   
}
