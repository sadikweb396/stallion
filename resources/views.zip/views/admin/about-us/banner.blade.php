@extends('layouts.owner.app')

@section('content')
<div class="dash_body_inner">
    <div class="our_stallions stallions_details">
        <div class="add_new_stallions">
            <div class="satllion_title_search_m d-flex justify-space-between align-items-center mb20">
                <div class="stallions_title">
                    <h3>About us Banner</h3>
                </div>
                <div class="stallions_search">
                    <!-- You can add a search input here if needed -->
                </div>
            </div>
            <div class="stallions_tabs_main">
                <div class="tabs_i">
                    <div class="main_tab_content">
                        <div class="main_stallions_d">
                            <div class="title_bar mb20">
                                <p class="text-center">About us Banner</p>
                            </div>
                            <div class="stallions_d_form mb50">
                                <form method="post" action="{{ route('admin.about-us.banner-store') }}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form_main">
                                        <div class="form-group">
                                            <label for="heading">Heading</label>
                                            <input type="text" name="heading" value="@if($banner){{$banner->heading}}@endif" required />
                                        </div>
                                    </div>

                                    <div class="form_main">
                                        <div class="form-group">
                                            <label for="text">Text</label>
                                            <textarea name="text" id="text">@if($banner){{$banner->text}}@endif</textarea>
                                        </div>
                                    </div>

                                    <div class="form_main">
                                        <div class="form-group">
                                            <label for="imageUpload">Image</label>
                                            <input type="file" name="image" id="imageUpload" onchange="previewImage(event)">
                                            <img id="imagePreview" src="@if($banner){{url($banner->image)}}@endif" style="max-width: 300px;" />
                                        </div>
                                    </div>

                                    <div class="update_btn text-right mb50">
                                        <button type="submit" class="btn btn_i black_btn">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</div>

@push('scripts')
<script>
    ClassicEditor
        .create(document.querySelector('#text'))
        .catch(error => {
            console.error(error);
        });
</script>
@endpush

@endsection
