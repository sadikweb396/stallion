<div class="close_btn_p">
    <i class="fa-solid fa-xmark"></i>
</div>

@if(!empty($event))
    <div class="event-card">
        <div class="event_f_i">
            <img src="{{ url($event->image) }}" alt="Event Image" class="img-cover" />
        </div>
        <div class="event_details">
            <div class="follow_btn">
                @auth
                    @php $count = DB::table('followevents')->where('eventId', $event->id)->where('userId', auth()->user()->id)->count(); @endphp
                    @if($count == 1)
                        <a class="unfollow-button btn btn_i black_btn" data="{{ $event->id }}" href="javascript:void(0)"> Unfollow </a>
                    @else
                        <a class="follow-button btn btn_i black_btn" data="{{ $event->id }}" href="javascript:void(0)">+ Follow </a>
                    @endif
                @else
                    <a class="follow-button btn btn_i black_btn" id="featured_stallions" data="{{ $event->id }}" href="javascript:void(0)">+ Follow </a>
                @endauth
            </div>
            <div class="event_badge">
                <span class="icon">
                    @if($event->mark_event_prestigious)
                        <img src="{{ url('/assets/frontend/image/Rectangle 137.png') }}" alt="unique" class="img-contain" />
                    @endif
                </span>
                @if($event->mark_event_prestigious)
                    <span>
                        <a href="#" class="btn btn_i black_btn">Prestigious Event</a>
                    </span>
                @endif
            </div>
            <h2 class="mb20">{{ $event->event_name }}</h2>
            <div class="events_inf mb20">
                <p>
                    <span><strong>Association Hosting Event:</strong></span>
                    <span>{{ $event->association_hosting_event }}</span>
                </p>
                <p>
                    <span><strong>Event Address:</strong></span>
                    <span>{{ $event->address }}</span>
                </p>
                <p>
                    <span><strong>Start Date:</strong></span>
                    <span>{{ $event->start_date }}</span>
                </p>
                <p>
                    <span><strong>End Date:</strong></span>
                    <span>{{ $event->end_date }}</span>
                </p>
                <p>
                    <span><strong>Nomination Date:</strong></span>
                    <span>{{ $event->nomination_date }}</span>
                </p>
                <p>
                    <span><strong>Contact:</strong></span>
                    <span>{{ $event->contact }}</span>
                </p>
                <p>
                    <span><strong>Phone:</strong></span> 
                    <span>{{ $event->phone }}</span>
                </p>
                <p>
                    <span><strong>Email:</strong></span>
                    <span>{{ $event->email }}</span>
                </p>
                <p>
                    <span><strong>Zone:</strong></span>
                    <span>{{ $event->zone }}</span>
                </p>
                <p>
                    <span><strong>State:</strong></span>
                    <span>{{ $event->state }}</span>
                </p>
            
            </div>
          
            @php $links = DB::table('links')->where('event_id', $event->id)->get(); @endphp
            <div class="events_btn">
            <a href="{{ url($event->websitelink) }}" class="btn btn_i black_btn link-program">Webiste Link</a>
                @foreach($links as $link)
                    @if(!empty($link->event_link))
                        <a href="{{ url($link->event_link) }}" class="btn btn_i black_btn link-program">{{ $link->event_name }}</a>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
@endif
